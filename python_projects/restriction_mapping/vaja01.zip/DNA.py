class DNA:
    def __init__(self, data):
        self.m_data = data
        self.m_N = -1
        self.m_L = []
        self.m_results = []
