#ifndef DMA_MYMALLOC_H
#define DMA_MYMALLOC_H

#include <stddef.h>

void* mymalloc(size_t size);
void myFree(void* m);

size_t customRound(size_t n);
void allocNewPage();
void init();
void debug_print_info();

#endif //DMA_MYMALLOC_H
